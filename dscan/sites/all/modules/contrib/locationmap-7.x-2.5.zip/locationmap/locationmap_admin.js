(function($){
  // DISABLED: When address changes, remove previous latitude and longitude.
  // TODO: Dynamically look up new coordinates when address changes.
  $("#edit-locationmap-address").bind('change', function() {
  // $('#edit-locationmap-lat').val("");
  // $('#edit-locationmap-lng').val("");
  });
})(jQuery);