<?php
/**
 * Created by PhpStorm.
 * User: podarokua
 * Date: 18.12.13
 * Time: 19:31
 */

namespace Drupal\gmap;


class GmapMarkerInfo {

} 