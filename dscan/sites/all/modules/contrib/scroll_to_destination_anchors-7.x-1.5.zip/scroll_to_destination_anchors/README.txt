**Description:
Makes destination anchor links that start with a hashtag scroll users to the
destination instead of the browser default jump behavior.

**Installation:
See the INSTALL.txt file.
