Rabbit Hole is a module that adds the ability to control what should happen when
an entity is being viewed at its own page.

Please refer to the full project page at http://drupal.org/project/rabbit_hole
for further information.
