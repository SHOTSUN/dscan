Module: OnScroll

Description
===========
OnScroll is an advert serving technology that delivers advertising only when the code is in a viewable area of the page.
This helps improve delivery of campaigns and improves CTR, only shown to users that scroll down the length of the page.

Compatible with:
DFP

Installation
============
Put the modules into your sites/module folder
Enable the module and set user permissions

Configuration
=============
Visit /admin/config/system/onscroll
or via menus: Configuration > System > OnScroll
